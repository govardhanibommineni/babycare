package com.cts.springmvc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.springmvc.dao.impl.BabyDAO;
import com.cts.springmvc.entity.Baby;

@Service//get from @repository and connects to @controller
@Transactional//database transaction
public class BabyService {
	@Autowired
	private BabyDAO dao1;
	public void createUser1(Baby reg) 
	{
	
		
		dao1.createUser1(reg);
	}
			
		@Transactional
		public List<Baby> getemps() 
		{
			
			return dao1.getBaby();
		}

		@Transactional
		public void deleteemps(long theId)
		{
			dao1.deleteUser1(theId);
		}


		

	}
		
	