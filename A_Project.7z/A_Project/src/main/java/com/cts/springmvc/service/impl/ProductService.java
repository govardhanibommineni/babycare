package com.cts.springmvc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.springmvc.dao.impl.ProductDAO;
import com.cts.springmvc.entity.Product;

@Service//get from @repository and connects to @controller
@Transactional//database transaction
public class ProductService {
	@Autowired
	private ProductDAO dao1;
	public void createUser(Product reg) 
	{
	
		
		dao1.createUser2(reg);
	}
			
		@Transactional
		public List<Product> getemps() 
		{
			
			return dao1.getProduct();
		}

		@Transactional
		public void deleteemps1(long theId)
		{
			dao1.deleteUser2(theId);
		}


		

	}
		
	