package com.cts.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.springmvc.entity.Product;
import com.cts.springmvc.service.impl.ProductService;

@Controller
public class ProductController {
	@Autowired
	private  ProductService pService1;
	@RequestMapping("productdata")
	public String createUser2(Model m) 
	{	
		//employee attribute==modelattribute in register.jsp
		m.addAttribute("product",new Product());
		return "Product_Register";//register.jsp==form action=register
	}
	//insertion
	@RequestMapping(value = "pregister", method = RequestMethod.POST)
	public String createUser2(@ModelAttribute Product user1,Model m)
	{
		pService1.createUser(user1);//save(employee)
		 return "redirect:/view10"; //redirect to request pattern::view
	       }
	//selection
	@RequestMapping(value = "view10", method = RequestMethod.GET)
	public String view(@ModelAttribute Product user1,Model m)
	{
		List<Product> obj=pService1.getemps();
		m.addAttribute("emps",obj);//emps can beaccessin ViewEmp.jsp
			return "ProductDataView";//ViewEmp.jsp
	}
	
	@RequestMapping(value = "view20", method = RequestMethod.GET)
	public String view2(@ModelAttribute Product user1,Model m)
	{
		List<Product> obj=pService1.getemps();
		m.addAttribute("emps",obj);//emps can beaccessin ViewEmp.jsp
			return "ProductDataView2";//ViewEmp.jsp
	}
	
	//deletion
    @RequestMapping(value="/deleteemps2/{delno}",method = RequestMethod.GET)    
    public String delemp2(@PathVariable int delno)
    {    
        pService1.deleteemps1(delno);
        return "redirect:/view10"; //call req pattern /view
    } 
       
}
