package com.cts.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class WebRedirectController {

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String welcome() {
		System.out.println("Application Startup Welcome Page");
		return "welcome";
	}

	@RequestMapping(value = "/redirect_page", method = RequestMethod.GET)
	public String redirect() {
		System.out.println("Redirecting Result To The Final Page");
		return "redirect:home";
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String finalPage() {
		System.out.println("Showing The Redirected Page");
		return "home";
	}
	
	@RequestMapping(value = "/msgsend", method = RequestMethod.GET)
	public String msgsend() {
		System.out.println("Msg send ");
		return "msgsend";
	}
	
	@RequestMapping(value = "/admincontact", method = RequestMethod.GET)
	public String admincontact() {
		System.out.println("Admincontact redirect page");
		return "admincontact";
	}
	
	@RequestMapping(value = "/userlogout", method = RequestMethod.GET)
	public String userlogout() {
		System.out.println("userlogout redirect page");
		return "userlogout";
	}
	
	@RequestMapping(value = "/order", method = RequestMethod.GET)
	public String order() {
		System.out.println("order redirect page");
		return "order";
	}

	@RequestMapping(value = "/loginhome", method = RequestMethod.GET)
	public String loginhome() {
		System.out.println("loginhome redirect page");
		return "loginhome";
	}
}