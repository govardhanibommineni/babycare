package com.cts.springmvc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.springmvc.dao.impl.UserDAO;
import com.cts.springmvc.entity.User;

//SERVICE IS THE MIDDLE LAYER
@Service//get from @repository and connects to @controller
@Transactional//database transaction
public class UserService {

	@Autowired
	private UserDAO UDAO1;
	
	public void createUser3(User employee) 
	{
	
		
		UDAO1.createUser3(employee);	
	}
	
	@Transactional
	public List<User> getemps() 
	{
		
		return UDAO1.getEmployee();
	}

	@Transactional
	public void deleteUser3(long theId)
	{
		UDAO1.deleteUser3(theId);
	}
	 //call controller
    public boolean checkLogin(String userName, String userPassword){
        System.out.println("In Service class...Check Login");
        return UDAO1.checkLogin(userName, userPassword);
 }
/*
    @Override
    public Employee getEmployee(Employee employee) {
        //
        //
        //
        return employeeDAO1.getEmployee(employee);
    }
	
*/

	

}