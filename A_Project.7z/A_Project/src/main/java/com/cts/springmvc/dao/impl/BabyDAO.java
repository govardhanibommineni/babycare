package com.cts.springmvc.dao.impl;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cts.springmvc.entity.Baby;

@Repository//marker for persistence layer
public class BabyDAO {
	@Autowired
	SessionFactory sessionFactory;//dispatcher-servlet.xm
	public void createUser1(Baby reg1) {
		Session session = sessionFactory.openSession();
		session.save(reg1);//persist hibernate
		System.out.println("Record Inserted");
		session.close();
	}
	public List<Baby> getBaby() 
	{
		//get the hibernate session
		Session session = sessionFactory.openSession();
		//create a query.. sort by lastName
	//sorting the record by name 	
		Query theQuery = session.createQuery("from Baby order by name");
		List<Baby> e1 = theQuery.list();
		return e1;
	}
	public void deleteUser1(long theId)
	{
		Session session = sessionFactory.openSession();
		//:abc runtime variable
		Query theQuery = session.createQuery("delete from Baby where id=:abc");
		theQuery.setParameter("abc", theId);
		theQuery.executeUpdate();
	}

}


