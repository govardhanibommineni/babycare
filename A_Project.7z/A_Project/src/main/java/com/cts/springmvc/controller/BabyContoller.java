package com.cts.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cts.springmvc.entity.Baby;
import com.cts.springmvc.service.impl.BabyService;

@Controller
public class BabyContoller {
	@Autowired
	private  BabyService bService1;
	
@RequestMapping("baby")
public String createUser1(Model m) 
{	
	//employee attribute==modelattribute in register.jsp
m.addAttribute("baby1",new Baby());
return "Baby_Register";//register.jsp==form action=register
}
	//insertion
@RequestMapping(value = "bregister", method = RequestMethod.POST)
public String createUser1(@ModelAttribute Baby user11,Model m)
{
	bService1.createUser1(user11);//save(employee)
 return "redirect:/view4"; //redirect to request pattern::view
   }
	
//selection
@RequestMapping(value = "view4", method = RequestMethod.GET)
public String view1(@ModelAttribute Baby user21,Model m)
{
	List<Baby> obj=bService1.getemps();
	m.addAttribute("emps",obj);//emps can beaccessin ViewEmp.jsp
	return "babysucessful";//ViewEmp.jsp
}
@RequestMapping(value = "view2", method = RequestMethod.GET)
public String view(@ModelAttribute Baby user1,Model m)
{
	List<Baby> obj=bService1.getemps();
	m.addAttribute("emps",obj);//emps can beaccessin ViewEmp.jsp
		return "BabyDataView";//ViewEmp.jsp
}
	//deletion
	//deletion
@RequestMapping(value="/deleteemps3/{delno}",method = RequestMethod.GET)    
public String delemp(   		@PathVariable   		int delno)
{    
    bService1.deleteemps(delno);
    return "redirect:/view2"; //call req pattern /view
} 
       
}
