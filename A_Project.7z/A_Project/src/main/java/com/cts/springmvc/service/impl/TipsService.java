package com.cts.springmvc.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cts.springmvc.dao.impl.TipsDAO;
import com.cts.springmvc.entity.Tips;

@Service//get from @repository and connects to @controller
@Transactional//database transaction
public class TipsService {
	@Autowired
	private TipsDAO dao1;
	public void createtips(Tips reg) 
	{
			
		dao1.createTips(reg);
	}
			
		@Transactional
		public List<Tips> gettips() 
		{
			
			return dao1.getTips();
		}

		@Transactional
		public void deletetips(long theId)
		{
			dao1.deleteTips(theId);
		}

		public boolean checkTip(int age, String tiptype){
	        System.out.println("In Service class...Check Login");
	        return dao1.checkLog(age, tiptype);
		

	}
		
}