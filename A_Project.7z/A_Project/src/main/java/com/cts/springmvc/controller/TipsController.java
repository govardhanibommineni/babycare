package com.cts.springmvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.springmvc.entity.Tips;
import com.cts.springmvc.entity.Tips;
import com.cts.springmvc.entity.Tips;
import com.cts.springmvc.entity.Tips;
import com.cts.springmvc.service.impl.TipsService;

@Controller
public class TipsController {
	@Autowired
	private  TipsService bService1;
	@RequestMapping("tips")
	public String createtips(Model m) 
	{	
		//employee attribute==modelattribute in register.jsp
		m.addAttribute("Tips",new Tips());
		return "Tips";//register.jsp==form action=register
	}
	//insertion
	@RequestMapping(value = "Tips_Register", method = RequestMethod.POST)
	public String createtips(@ModelAttribute Tips Tips,Model m)
	{
		bService1.createtips(Tips);//save(employee)
		 return "redirect:/tipsview2"; //redirect to request pattern::view
	       }
	//selection
	@RequestMapping(value = "tipsview2", method = RequestMethod.GET)
	public String view(@ModelAttribute Tips Tips,Model m)
	{
		List<Tips> obj=bService1.gettips();
		m.addAttribute("emps",obj);//emps can beaccessin ViewEmp.jsp
			return "TipsDataView";//ViewEmp.jsp
	}
	
	
	@RequestMapping(value = "tipsview20", method = RequestMethod.GET)
	public String tipsview20(@ModelAttribute Tips Tips,Model m)
	{
		List<Tips> obj=bService1.gettips();
		m.addAttribute("emps",obj);//emps can beaccessin ViewEmp.jsp
			return "TipsDataView2";//ViewEmp.jsp
	}
	
	//deletion
	//deletion
    @RequestMapping(value="/deletetips/{delno}",method = RequestMethod.GET)    
    public String delemp(   		@PathVariable   		int delno)
    {    
        bService1.deletetips(delno);
        return "redirect:/tipsview2"; //call req pattern /view
    } 

}