package com.cts.springmvc.controller; 

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

//import com.cts.EmployeeBean;
import com.cts.springmvc.entity.User;
import com.cts.springmvc.service.impl.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService eService1;
	@RequestMapping("register")
	public String createUser23(Model m) 
	{	
		//employee attribute==modelattribute in register.jsp
		m.addAttribute("user",new User());
		return "register";//register.jsp==form action=register
	}
	//insertion
	@RequestMapping(value = "register", method = RequestMethod.POST)
	public String createUser23(@ModelAttribute User employee1,Model m)
	{
		eService1.createUser3(employee1);//save(employee)
		 return "redirect:/login"; //redirect to request pattern::view
	       }
	//selection
	@RequestMapping(value = "view", method = RequestMethod.GET)
	public String view(@ModelAttribute User employee1,Model m)
	{
		List<User> obj=eService1.getemps();
		m.addAttribute("emps",obj);//emps can beaccessin ViewEmp.jsp
			return "UserDataView";//ViewEmp.jsp
	}
	//deletion
    @RequestMapping(value="/deleteemps/{delno}",method = RequestMethod.GET)    
    public String delemp(
    		@PathVariable 
    		int delno)
    {    
        eService1.deleteUser3(delno);
        return "redirect:/view"; //call req pattern /view
    } 

	@RequestMapping(value = "login", method = RequestMethod.GET)
	public ModelAndView viewLogin(@ModelAttribute User employee) {
		return new ModelAndView("login");//login.jsp
	}


	@RequestMapping(value = "login", method = RequestMethod.POST)
	public ModelAndView processLogin(@ModelAttribute User employee) 
	{
		boolean emp = eService1.checkLogin(employee.getUsername(),employee.getPassword());
		ModelAndView model = null;
		if (emp) 
		{
			model = new ModelAndView("loginhome");//loginsuccess.jsp
			model.addObject("emp", employee.getUsername());//access in jsp
			
		} else {
			model = new ModelAndView("login");//login.jsp
			model.addObject("result", "Invalid Username or Password!!");
		}
		return model;
	}

        

}