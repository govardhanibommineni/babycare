/**
 * 
 */
function do11()
{	
	alert("Wow JS is working in SPRING MVC....");
}